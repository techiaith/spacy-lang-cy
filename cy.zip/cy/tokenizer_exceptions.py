# encoding: utf8
from __future__ import unicode_literals

from ...symbols import ORTH, LEMMA, NORM


TOKENIZER_EXCEPTIONS = {

    "a.y.y.b": [
        {ORTH: "a.", LEMMA: "ac"},
        {ORTH: "y.", LEMMA: "yn"},
        {ORTH: "y.", LEMMA: "y"},
        {ORTH: "b", LEMMA: "blaen"}
    ],

    "a.y.b": [
        {ORTH: "a.", LEMMA: "ac"},
        {ORTH: "y.", LEMMA: "yn y"},
        {ORTH: "b", LEMMA: "blaen"}
    ],

    "h.y.": [
        {ORTH: "h.", LEMMA: "hynny"},
        {ORTH: "y.", LEMMA: "yw"}
    ],

    "e.e.": [
        {ORTH: "e.", LEMMA: "er"},
        {ORTH: "e.", LEMMA: "enghraifft"}
    ],

    "A.C.": [
        {ORTH: "A.", LEMMA: "Aelod"},
        {ORTH: "C.", LEMMA: "Cynulliad"}
    ],

    "A.S.": [
        {ORTH: "A.", LEMMA: "Aelod"},
        {ORTH: "S.", LEMMA: "Seneddol"}
    ],

    "A.S.E.": [
        {ORTH:"A.", LEMMA: "Aelod"},
        {ORTH:"S.", LEMMA: "Seneddol"},
        {ORTH:"E.", LEMMA: "Ewropeaidd"}
    ],

    "g'ath": [{ORTH: "g'ath", LEMMA: "ca'th", NORM: "gafodd"}],

    "c'ath": [{ORTH: "c'ath", LEMMA: "ca'th", NORM: "gafodd"}]



}



# Times

for h in range(1, 12 + 1):
    for period in ["a.m.", "am"]:
        TOKENIZER_EXCEPTIONS["%d%s" % (h, period)] = [
            {ORTH: "%d" % h},
            {ORTH: period, LEMMA: "a.m.", NORM: "a.m."},
        ]
    for period in ["p.m.", "pm"]:
        TOKENIZER_EXCEPTIONS["%d%s" % (h, period)] = [
            {ORTH: "%d" % h},
            {ORTH: period, LEMMA: "p.m.", NORM: "p.m."},
        ]

for orth in [
    "'d",
    "a.m.",
    "Adm.",
    "Bros.",
    "co.",
    "Co.",
    "Corp.",
    "D.C.",
    "Dr.",
    "e.g.",
    "E.g.",
    "E.G.",
    "Gen.",
    "Gov.",
    "i.e.",
    "I.e.",
    "I.E.",
    "Inc.",
    "Jr.",
    "Ltd.",
    "Md.",
    "Messrs.",
    "Mo.",
    "Mont.",
    "Mr.",
    "Mrs.",
    "Ms.",
    "p.m.",
    "Ph.D.",
    "Prof.",
    "Rep.",
    "Rev.",
    "Sen.",
    "St.",
    "vs.",
    "v.s.",
]:
    TOKENIZER_EXCEPTIONS[orth] = [{ORTH: orth}]
